import { v4 as uuid } from "uuid";
export default (req,res,next)=>{
  const cid = uuid();
  req.cid = cid;
  res.setHeader("x-correlation-id", cid);
  next();
};
