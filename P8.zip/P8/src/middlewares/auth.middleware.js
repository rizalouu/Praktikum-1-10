import jwt from "jsonwebtoken";
import env from "../config/env.js";
export default (req,res,next)=>{
  const t=req.headers.authorization?.split(" ")[1];
  if(!t) return res.sendStatus(401);
  req.user=jwt.verify(t,env.jwtAccessSecret);
  next();
};
