import { Router } from "express";
import { health } from "../controllers/system.controller.js";
const r=Router();
r.get("/health",health);
export default r;
