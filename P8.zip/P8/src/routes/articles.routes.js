import { Router } from "express";
import * as c from "../controllers/articles.controller.js";
import verify from "../middlewares/auth.middleware.js";
const r=Router();
r.get("/",c.listArticles);
r.post("/",verify,c.createArticle);
export default r;
