import jwt from "jsonwebtoken";
import env from "../config/env.js";
export const signAccess=p=>jwt.sign(p,env.jwtAccessSecret,{expiresIn:env.jwtAccessExpires});
export const signRefresh=p=>jwt.sign(p,env.jwtRefreshSecret,{expiresIn:env.jwtRefreshExpires});
