export const success = (res, data, message="OK", code=200) =>
  res.status(code).json({ success:true, message, data });
