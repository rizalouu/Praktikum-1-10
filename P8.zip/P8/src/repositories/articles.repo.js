import mongoose from "mongoose";
const schema=new mongoose.Schema({
  title:String,slug:String,content:String,
  tags:[String],status:String,authorId:String
},{timestamps:true});
export default mongoose.model("Article",schema);
