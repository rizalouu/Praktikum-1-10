import * as s from "../services/articles.service.js";
import { success } from "../utils/response.js";
export const listArticles=async(req,res)=>success(res,await s.list());
export const createArticle=async(req,res)=>success(res,await s.create(req.body,req.user),"Created",201);
