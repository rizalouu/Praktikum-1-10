export const health=(req,res)=>{
  res.json({success:true,status:"UP",time:new Date()});
};
