import * as s from "../services/auth.service.js";
import { success } from "../utils/response.js";
export const register=async(req,res)=>success(res,await s.register(req.body),"Registered",201);
export const login=async(req,res)=>success(res,await s.login(req.body));
