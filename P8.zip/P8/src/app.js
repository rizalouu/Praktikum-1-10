import express from "express";
import cors from "cors";
import helmet from "helmet";
import pinoHttp from "pino-http";
import logger from "./utils/logger.js";
import correlation from "./middlewares/correlationId.middleware.js";
import systemRoutes from "./routes/system.routes.js";
import articlesRoutes from "./routes/articles.routes.js";
import authRoutes from "./routes/auth.routes.js";
import notFound from "./middlewares/notFound.middleware.js";
import errorHandler from "./middlewares/error.middleware.js";

const app = express();
app.use(express.json());
app.use(cors());
app.use(helmet());
app.use(correlation);
app.use(pinoHttp({ logger }));

app.use(systemRoutes);
app.use("/api/articles", articlesRoutes);
app.use("/api/auth", authRoutes);

app.use(notFound);
app.use(errorHandler);

export default app;
