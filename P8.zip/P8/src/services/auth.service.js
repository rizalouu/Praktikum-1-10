import bcrypt from "bcrypt";
import User from "../repositories/users.repo.js";
import { signAccess, signRefresh } from "../utils/jwt.js";
export const register=async d=>{
  const h=await bcrypt.hash(d.password,10);
  return User.create({...d,password:h});
};
export const login=async({email,password})=>{
  const u=await User.findOne({email});
  if(!u) throw Error();
  const ok=await bcrypt.compare(password,u.password);
  if(!ok) throw Error();
  const at=signAccess({id:u.id,role:u.role});
  const rt=signRefresh({id:u.id});
  u.refreshToken=rt; await u.save();
  return {accessToken:at,refreshToken:rt};
};
