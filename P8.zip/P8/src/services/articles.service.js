import Article from "../repositories/articles.repo.js";
export const list=()=>Article.find({status:"published"});
export const create=(data,user)=>Article.create({...data,authorId:user.id});
