
```md
# Praktikum 8 – Secure REST API dengan JWT & MongoDB Atlas

## Mata Kuliah
Web Service Engineering

## Nama
Rizal Kurniawan

## Deskripsi
Praktikum ini bertujuan untuk membangun **REST API yang aman (secure)** menggunakan:
- **Node.js**
- **Express.js**
- **MongoDB Atlas**
- **JWT (JSON Web Token)**

API yang dibuat memiliki fitur:
- Autentikasi (Register & Login)
- Proteksi endpoint menggunakan JWT
- CRUD Article
- Error handling
- Koneksi database cloud (MongoDB Atlas)

---

## Tools & Teknologi
- Node.js
- Express.js
- MongoDB Atlas
- Mongoose
- JSON Web Token (JWT)
- Postman
- Nodemon
- dotenv

---

## Struktur Folder
```

P8/
├── src/
│   ├── config/
│   │   └── db.js
│   ├── controllers/
│   │   ├── auth.controller.js
│   │   ├── articles.controller.js
│   │   └── system.controller.js
│   ├── middlewares/
│   ├── routes/
│   │   ├── auth.routes.js
│   │   ├── articles.routes.js
│   │   └── system.routes.js
│   ├── services/
│   ├── app.js
│   └── server.js
├── .env
├── .env.example
├── package.json
└── README.md

````

---

## Instalasi & Menjalankan Project

### 1. Clone / Extract Project
Masuk ke folder project:
```bash
cd P8
````

### 2. Install Dependencies

```bash
npm install
```

### 3. Konfigurasi Environment

Copy file `.env.example` menjadi `.env`:

```bash
cp .env.example .env
```

Isi file `.env`:

```env
PORT=3000
MONGO_URI=mongodb+srv://<username>:<password>@<cluster>.mongodb.net/p8db?retryWrites=true&w=majority
JWT_ACCESS_SECRET=secret123
JWT_REFRESH_SECRET=secret123
JWT_ACCESS_EXPIRES=15m
JWT_REFRESH_EXPIRES=7d
```

---

### 4. Jalankan Server

```bash
npm run dev
```

Jika berhasil, akan muncul:

```
MongoDB connected
Server running on port 3000
```

---

## Daftar Endpoint API

### 1. Health Check

```
GET /health
```

Response:

```json
{
  "success": true,
  "status": "UP"
}
```

---

### 2. Register User

```
POST /api/auth/register
```

Body:

```json
{
  "name": "Rizal",
  "email": "rizal@mail.com",
  "password": "123456"
}
```

---

### 3. Login User

```
POST /api/auth/login
```

Body:

```json
{
  "email": "rizal@mail.com",
  "password": "123456"
}
```

Response:

```json
{
  "accessToken": "...",
  "refreshToken": "..."
}
```

---

### 4. Create Article (Protected)

```
POST /api/articles
```

Headers:

```
Authorization: Bearer <accessToken>
```

Body:

```json
{
  "title": "Artikel Pertama",
  "content": "Ini isi artikel praktikum 8"
}
```

---

### 5. Get All Articles

```
GET /api/articles
```

---

### 6. Get Article by ID

```
GET /api/articles/{id}
```

---

### 7. Update Article

```
PUT /api/articles/{id}
```

---

### 8. Delete Article

```
DELETE /api/articles/{id}
```

---

### 9. Error Handling

```
GET /api/salah
```

Response:

```json
{
  "success": false,
  "message": "Route not found"
}
```

---

## Pengujian

Pengujian API dilakukan menggunakan **Postman**, meliputi:

1. Health check
2. Register
3. Login
4. CRUD Article
5. Error handling

---

## Kesimpulan

Dengan praktikum ini, berhasil dibuat REST API yang:

* Terhubung ke MongoDB Atlas
* Menggunakan JWT untuk keamanan
* Menerapkan struktur backend yang rapi
* Siap digunakan sebagai dasar aplikasi backend

---

