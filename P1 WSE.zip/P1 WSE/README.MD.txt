
# 📘 README.md

## Demo Testing API – Kuliah 1

---

## 👤 Identitas

* Nama : **M. Rizal Kurniawan**
* Mata Kuliah : **Web Service Engineering**
* Materi : **Demo Testing API (Kuliah 1)**

---

## 📌 Deskripsi

Praktikum ini bertujuan untuk memahami cara melakukan **pengujian Web Service API** menggunakan aplikasi **Postman**.
Pengujian dilakukan terhadap **JSONPlaceholder API** dengan beberapa method HTTP, yaitu **GET, POST, PUT, dan DELETE**.

---

## 🛠️ Tools yang Digunakan

* Postman
* JSONPlaceholder API
* Koneksi Internet

---

## 🌐 API yang Digunakan

Base URL:

```
https://jsonplaceholder.typicode.com
```

---

## 🧪 Langkah-Langkah Pengujian API

### 1️⃣ GET – Menampilkan Semua Data Post

* Method: **GET**
* Endpoint:

  ```
  /posts
  ```
* URL Lengkap:

  ```
  https://jsonplaceholder.typicode.com/posts
  ```

**Hasil:**
Menampilkan seluruh data post dalam format JSON dengan status **200 OK**.

---

### 2️⃣ GET – Menampilkan Data Post Berdasarkan ID

* Method: **GET**
* Endpoint:

  ```
  /posts/1
  ```

**Hasil:**
Menampilkan satu data post dengan ID = 1 dan status **200 OK**.

---

### 3️⃣ GET – Menggunakan Query Parameter

* Method: **GET**
* Endpoint:

  ```
  /comments?postId=1
  ```

**Hasil:**
Menampilkan daftar komentar dengan `postId = 1` dan status **200 OK**.

---

### 4️⃣ POST – Menambahkan Data

* Method: **POST**
* Endpoint:

  ```
  /posts
  ```
* Body (JSON):

```json
{
  "title": "Belajar API",
  "body": "Ini percobaan pertama",
  "userId": 1
}
```

**Hasil:**
Data berhasil ditambahkan dan server mengembalikan response dengan status **201 Created**.

---

### 5️⃣ PUT – Mengubah Data

* Method: **PUT**
* Endpoint:

  ```
  /posts/1
  ```
* Body (JSON):

```json
{
  "id": 1,
  "title": "Belajar API Update",
  "body": "Isi sudah diperbarui",
  "userId": 1
}
```

**Hasil:**
Data berhasil diperbarui dengan status **200 OK**.

---

### 6️⃣ DELETE – Menghapus Data

* Method: **DELETE**
* Endpoint:

  ```
  /posts/1
  ```

**Hasil:**
Data berhasil dihapus dengan status **200 OK**.

---

## 📂 Bukti Pengujian

Bukti pengujian berupa:

* Screenshot request dan response di Postman
* Terlihat URL, method, status code, dan response JSON

---

## 📌 Kesimpulan

Berdasarkan pengujian yang telah dilakukan, Postman dapat digunakan untuk melakukan testing API dengan berbagai method HTTP.
Setiap method memiliki fungsi yang berbeda dan menghasilkan response sesuai dengan request yang dikirimkan ke server.

