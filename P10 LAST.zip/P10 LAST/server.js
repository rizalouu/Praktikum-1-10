const express = require("express");
const mongoose = require("mongoose");
require("dotenv").config();

const productRoutes = require("./routes/productRoutes");
const authRoutes = require("./routes/authRoutes");

const app = express();
app.use(express.json());

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("✅ Koneksi ke MongoDB Atlas Berhasil!"))
  .catch((err) => console.error(err));

app.get("/", (req, res) => {
  res.send("API Praktikum 10 WSE Berjalan");
});

app.use("/api/v1/products", productRoutes);
app.use("/api/v1/auth", authRoutes);

app.listen(process.env.PORT, () => {
  console.log(`🚀 Server berjalan di http://localhost:${process.env.PORT}`);
});
