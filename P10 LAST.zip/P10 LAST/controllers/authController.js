const User = require("../models/User");
const generateToken = require("../utils/generateToken");

exports.login = async (req, res) => {
  const { username, password } = req.body;

  const user = await User.findOne({ username });
  if (!user || !(await user.matchPassword(password))) {
    return res.status(401).json({ message: "Login gagal" });
  }

  res.json({
    access_token: generateToken(user),
    token_type: "Bearer",
  });
};
