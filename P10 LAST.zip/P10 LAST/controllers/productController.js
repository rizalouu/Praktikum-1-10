const Product = require("../models/Product");

exports.getPublicProducts = async (req, res) => {
  const products = await Product.find();
  res.json(products);
};

exports.createProduct = async (req, res) => {
  if (req.user.role !== "admin")
    return res.status(403).json({ message: "Akses ditolak" });

  const product = await Product.create(req.body);
  res.json(product);
};

exports.updateProduct = async (req, res) => {
  if (req.user.role !== "admin")
    return res.status(403).json({ message: "Akses ditolak" });

  const product = await Product.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  res.json(product);
};

exports.deleteProduct = async (req, res) => {
  if (req.user.role !== "admin")
    return res.status(403).json({ message: "Akses ditolak" });

  await Product.findByIdAndDelete(req.params.id);
  res.json({ message: "Produk dihapus" });
};
