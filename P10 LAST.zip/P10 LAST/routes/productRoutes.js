const express = require("express");
const router = express.Router();

const validateApiKey = require("../middleware/validateApiKey");
const validateToken = require("../middleware/validateToken");
const productController = require("../controllers/productController");

router.get("/public", validateApiKey, productController.getPublicProducts);
router.post("/private", validateToken, productController.createProduct);
router.put("/private/:id", validateToken, productController.updateProduct);
router.delete("/private/:id", validateToken, productController.deleteProduct);

module.exports = router;
