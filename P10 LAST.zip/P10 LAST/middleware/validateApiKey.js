const ApiKey = require("../models/ApiKey");

module.exports = async (req, res, next) => {
  const apiKey = req.header("x-api-key");

  if (!apiKey) {
    return res.status(401).json({ message: "API Key tidak ada" });
  }

  const key = await ApiKey.findOne({ key: apiKey, status: "active" });
  if (!key) {
    return res.status(401).json({ message: "API Key tidak valid" });
  }

  next();
};
