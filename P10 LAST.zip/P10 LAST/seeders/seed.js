const mongoose = require("mongoose");
require("dotenv").config();

const Product = require("../models/Product");
const ApiKey = require("../models/ApiKey");
const User = require("../models/User");

mongoose.connect(process.env.MONGO_URI);

async function seed() {
  await Product.deleteMany();
  await ApiKey.deleteMany();
  await User.deleteMany();

  await ApiKey.create({
    key: "PRACTICUM_API_KEY_A_1234567890",
    status: "active",
  });

  await User.create([
    { username: "admin", password: "password123", role: "admin" },
    { username: "userbiasa", password: "userpass", role: "user" },
  ]);

  console.log("✅ Seeder berhasil dijalankan");
  process.exit();
}

seed();
