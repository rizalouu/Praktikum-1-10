const mongoose = require("mongoose");

const apiKeySchema = new mongoose.Schema({
  key: String,
  status: String,
});

module.exports = mongoose.model("ApiKey", apiKeySchema);
