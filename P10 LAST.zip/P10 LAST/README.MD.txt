
```md
# Praktikum 10 – Web Service Engineering (WSE)
## REST API dengan Authentication & Authorization (JWT)

Repository ini berisi implementasi REST API menggunakan **Node.js, Express, MongoDB**, serta **JWT (JSON Web Token)** untuk kebutuhan **authentication** dan **authorization** sesuai modul Praktikum 10 WSE.

---

## 📌 Tujuan Praktikum
1. Menerapkan REST API menggunakan Express.js  
2. Mengimplementasikan autentikasi menggunakan JWT  
3. Menerapkan authorization berbasis role (admin & user)  
4. Melakukan pengujian endpoint menggunakan Postman  

---

## 🛠️ Teknologi yang Digunakan
- Node.js
- Express.js
- MongoDB Atlas
- Mongoose
- JSON Web Token (JWT)
- Postman

---

## 📂 Struktur Folder
```

P10-LAST
├── controllers
│   ├── authController.js
│   └── productController.js
├── middlewares
│   ├── authMiddleware.js
│   └── roleMiddleware.js
├── models
│   ├── User.js
│   └── Product.js
├── routes
│   ├── authRoutes.js
│   └── productRoutes.js
├── seeders
│   └── seed.js
├── .env
├── server.js
└── package.json

````

---

## ⚙️ Instalasi & Menjalankan Aplikasi

### 1️⃣ Clone / Extract Project
```bash
extract project
cd P10-LAST
````

### 2️⃣ Install Dependency

```bash
npm install
```

### 3️⃣ Konfigurasi Environment

Buat file `.env` dan isi:

```
PORT=3000
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/dbname
JWT_SECRET=secretkey123
```

### 4️⃣ Jalankan Seeder

```bash
node seeders/seed.js
```

### 5️⃣ Jalankan Server

```bash
node server.js
```

Server berjalan di:

```
http://localhost:3000
```

---

## 🔐 Authentication

### Login

**POST**

```
/api/v1/auth/token
```

Body (JSON):

```json
{
  "username": "admin",
  "password": "password123"
}
```

Response:

```json
{
  "access_token": "jwt_token",
  "token_type": "Bearer"
}
```

---

## 📦 Endpoint Produk

### 🔓 Public

* **GET** `/api/v1/products`
* **GET** `/api/v1/products/:id`

### 🔒 Private (Admin Only)

* **POST** `/api/v1/products/private`
* **PUT** `/api/v1/products/private/:id`
* **DELETE** `/api/v1/products/private/:id`

> Endpoint private membutuhkan header:

```
Authorization: Bearer <token>
```

---

## 👥 Authorization (Role Based)

| Role  | Akses       |
| ----- | ----------- |
| Admin | CRUD Produk |
| User  | Read Only   |

Jika user biasa mengakses endpoint private, sistem akan menolak dengan status:

```
403 Forbidden
```

---

## 🧪 Pengujian (Postman)

1. Login sebagai admin dan user
2. Simpan token JWT
3. Gunakan token pada endpoint private
4. Pastikan:

   * Admin berhasil
   * User biasa ditolak

---

## 📸 Bukti Screenshot

* Login Admin
* Login User
* CRUD Produk (Admin)
* Akses Ditolak (User)

---

## ✅ Kesimpulan

Implementasi REST API dengan JWT authentication dan authorization berbasis role berhasil dilakukan. Sistem mampu membedakan hak akses antara admin dan user sesuai kebutuhan praktikum.

---

**Nama** : M. Rizal Kurniawan
**Mata Kuliah** : Web Service Engineering
**Praktikum** : 10
