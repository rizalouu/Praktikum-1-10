import express from "express";
import swaggerUi from "swagger-ui-express";
import fs from "fs";
import yaml from "yaml";
import authRoutes from "./auth.routes.js";

const app = express();
app.use(express.json());

// Swagger
const swaggerFile = fs.readFileSync("./src/docs/swagger.yaml", "utf8");
const swaggerDocument = yaml.parse(swaggerFile);
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Health check
app.get("/health", (req, res) => {
  res.json({ success: true, status: "UP" });
});

// Auth routes
app.use("/api/auth", authRoutes);

export default app;
