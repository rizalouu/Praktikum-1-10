import express from "express";

const router = express.Router();

router.post("/register", (req, res) => {
  res.status(201).json({
    message: "Register success",
    data: req.body
  });
});

router.post("/login", (req, res) => {
  res.status(200).json({
    message: "Login success",
    token: "dummy-jwt-token"
  });
});

export default router;
