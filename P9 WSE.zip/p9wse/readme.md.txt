
---

```md
# Praktikum 9 – Web Service Engineering  
**Implementasi Swagger (OpenAPI) pada REST API Express.js**

## 📌 Deskripsi
Praktikum 9 bertujuan untuk mengimplementasikan **Swagger (OpenAPI)** sebagai dokumentasi REST API pada aplikasi berbasis **Express.js**. Dengan Swagger, seluruh endpoint API dapat didokumentasikan dan diuji secara langsung melalui browser tanpa menggunakan tools tambahan seperti Postman.

---

## 🎯 Tujuan Praktikum
1. Mengintegrasikan Swagger UI pada aplikasi Express.js  
2. Mendokumentasikan endpoint REST API menggunakan file YAML  
3. Melakukan pengujian endpoint API melalui Swagger UI  
4. Memastikan dokumentasi dan implementasi endpoint berjalan dengan baik  

---

## 🛠️ Tools & Teknologi
- Node.js
- Express.js
- Swagger UI Express
- YAML
- Nodemon

---

## 📁 Struktur Project
```

P9/
├── src/
│   ├── docs/
│   │   └── swagger.yaml
│   ├── auth.routes.js
│   ├── app.js
│   └── server.js
├── .env.example
├── package.json
└── README.md

````

---

## ⚙️ Instalasi & Menjalankan Project

### 1️⃣ Install Dependency
```bash
npm install
````

### 2️⃣ Menjalankan Server

```bash
npm run dev
```

Jika berhasil, akan muncul pesan:

```text
Server running on port 3000
```

---

## 🌐 Akses Aplikasi

* **Health Check**

  ```
  http://localhost:3000/health
  ```

* **Swagger UI**

  ```
  http://localhost:3000/api-docs
  ```

---

## 🧪 Pengujian API Menggunakan Swagger

### ✅ GET /health

Digunakan untuk mengecek status server.

**Response:**

```json
{
  "success": true,
  "status": "UP"
}
```

---

### ✅ POST /api/auth/register

Digunakan untuk registrasi user.

**Request Body:**

```json
{
  "name": "Rizal",
  "email": "rizal@mail.com",
  "password": "123456"
}
```

**Response:**

```json
{
  "message": "Register success",
  "data": {
    "name": "Rizal",
    "email": "rizal@mail.com",
    "password": "123456"
  }
}
```

---

### ✅ POST /api/auth/login

Digunakan untuk login user.

**Request Body:**

```json
{
  "email": "rizal@mail.com",
  "password": "123456"
}
```

**Response:**

```json
{
  "message": "Login success",
  "token": "dummy-jwt-token"
}
```

---

## 📸 Bukti Pengujian

Screenshot yang dilampirkan:

1. Server berjalan di terminal
2. Halaman Swagger UI
3. Hasil test GET `/health`
4. Hasil test POST `/api/auth/register`
5. Hasil test POST `/api/auth/login`

---

## 📝 Kesimpulan

Dengan menggunakan Swagger (OpenAPI), dokumentasi REST API menjadi lebih terstruktur, mudah dipahami, dan dapat langsung diuji. Implementasi ini mempermudah developer dalam memahami dan mengembangkan API secara berkelanjutan.

---
