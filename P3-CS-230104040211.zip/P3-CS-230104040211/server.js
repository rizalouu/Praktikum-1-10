const express = require('express');
const app = express();
const PORT = 3001;

app.use(express.json());

// ===== ROUTE HELLO =====
app.get('/hello', (req, res) => {
  res.send('Hello from Client-Server Architecture');
});

// ===== DATA MAHASISWA =====
let mahasiswa = [];

// POST mahasiswa
app.post('/mahasiswa', (req, res) => {
  mahasiswa.push(req.body);
  res.status(201).json({
    message: 'Data mahasiswa berhasil ditambahkan',
    data: req.body
  });
});

// GET mahasiswa
app.get('/mahasiswa', (req, res) => {
  res.status(200).json(mahasiswa);
});

// DELETE mahasiswa
app.delete('/mahasiswa/:nim', (req, res) => {
  mahasiswa = mahasiswa.filter(m => m.nim !== req.params.nim);
  res.status(200).json({
    message: 'Data mahasiswa berhasil dihapus'
  });
});

// PUT mahasiswa
app.put('/mahasiswa/:nim', (req, res) => {
  mahasiswa = mahasiswa.map(m =>
    m.nim === req.params.nim ? { ...m, ...req.body } : m
  );

  res.status(200).json({
    message: 'Data mahasiswa berhasil diperbarui'
  });
});

// ===== SERVER LISTEN =====
app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});
