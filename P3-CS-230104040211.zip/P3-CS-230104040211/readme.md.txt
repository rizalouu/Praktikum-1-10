

```md
# Praktikum 3 – Client Server Architecture

## Identitas
Nama: M. Rizal Kurniawan  
NIM: 230104040211  
Mata Kuliah: Web Service Engineering  

## Deskripsi
Praktikum ini bertujuan untuk memahami konsep Client-Server Architecture
dengan membangun REST API sederhana menggunakan Node.js dan Express.
API ini menyediakan layanan CRUD (Create, Read, Update, Delete) untuk
mengelola data mahasiswa.

## Tools yang Digunakan
- Node.js
- Express.js
- Postman
- Visual Studio Code

## Cara Menjalankan Aplikasi
1. Masuk ke folder project
2. Install dependency dengan perintah:
```

npm install

```
3. Jalankan server dengan perintah:
```

node server.js

```

Server akan berjalan pada alamat:
```

[http://localhost:3001](http://localhost:3001)

```

## Endpoint API

### GET /hello
Menampilkan pesan hello dari server sebagai tanda server berjalan dengan baik.

### POST /mahasiswa
Menambahkan data mahasiswa baru ke dalam sistem.

### GET /mahasiswa
Menampilkan seluruh data mahasiswa yang telah ditambahkan.

### PUT /mahasiswa/:nim
Mengubah data mahasiswa berdasarkan NIM tertentu.

### DELETE /mahasiswa/:nim
Menghapus data mahasiswa berdasarkan NIM tertentu.

## Pengujian
Pengujian API dilakukan menggunakan aplikasi Postman.
Seluruh endpoint telah diuji dan hasil pengujian dibuktikan dengan screenshot
yang disertakan dalam laporan praktikum.
```

---
